# Programacion3-Tarea5-JazmineMinaya
Tarea 5 - Diseño de Interfaces con JavaFX

## Nombre del Proyecto
Aplicación 1

## Estudiante
Jazmine Arleny Minaya Peralta

## Matrícula
1000-6143

## Materia
Programación 3

## Descripción
Este programa en Java integra una interfaz para registrar visitantes en una institución.

## Tecnologías utilizadas
- Java
- JDK 25
- Visual Studio Code